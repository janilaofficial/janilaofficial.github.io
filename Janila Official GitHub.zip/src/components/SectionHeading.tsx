import Reveal from "./Reveal";

interface SectionHeadingProps {
  index: string;
  eyebrow: string;
  title: string;
  accent?: string;
}

export default function SectionHeading({ index, eyebrow, title, accent }: SectionHeadingProps) {
  return (
    <Reveal>
      <div className="mb-12 sm:mb-16">
        <div className="flex items-center gap-4">
          <span className="font-mono text-[11px] tracking-[0.3em] text-brand">{index}</span>
          <span className="h-px w-14 bg-brand/50" />
          <span className="font-mono text-[11px] tracking-[0.3em] text-muted">{eyebrow.toUpperCase()}</span>
        </div>
        <h2 className="mt-5 font-display text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
          {title}{" "}
          {accent && <span className="text-stroke">{accent}</span>}
        </h2>
      </div>
    </Reveal>
  );
}
