import { useEffect, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { links, nav } from "../data/site";
import { cn } from "../utils/cn";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? window.scrollY / max : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled ? "nav-blur border-b border-line" : "border-b border-transparent"
      )}
    >
      {/* scroll progress */}
      <span
        className="absolute inset-x-0 top-0 h-[2px] origin-left bg-brand transition-transform duration-150"
        style={{ transform: `scaleX(${progress})` }}
      />

      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <a href="#home" className="group flex items-center gap-2.5">
          <span className="grid size-9 place-items-center rounded-lg bg-brand font-display text-sm font-extrabold text-ink transition-transform duration-300 group-hover:-rotate-6">
            JP
          </span>
          <span className="hidden font-mono text-[11px] tracking-[0.3em] text-muted sm:block">
            JANILA PRABASHWARA
          </span>
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {nav.map((item) => (
            <li key={item.href}>
              <a
                href={item.href}
                className="link-underline font-mono text-[11px] tracking-[0.22em] text-paper/70 transition-colors hover:text-brand"
              >
                {item.label.toUpperCase()}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <a
            href={links.whatsapp}
            target="_blank"
            rel="noreferrer"
            className="group hidden items-center gap-2 rounded-full bg-brand px-5 py-2.5 font-mono text-[11px] font-medium tracking-[0.15em] text-ink transition-all duration-300 hover:bg-brand-soft md:flex"
          >
            LET'S TALK
            <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
          <button
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
            className="grid size-10 place-items-center rounded-lg border border-line text-paper md:hidden"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </nav>

      {/* mobile menu */}
      <div
        className={cn(
          "nav-blur overflow-hidden border-b border-line transition-all duration-500 md:hidden",
          open ? "max-h-96" : "max-h-0 border-transparent"
        )}
      >
        <ul className="space-y-1 px-6 py-5">
          {nav.map((item, i) => (
            <li key={item.href}>
              <a
                href={item.href}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between py-2.5 font-display text-lg font-semibold text-paper/85 transition-colors hover:text-brand"
              >
                {item.label}
                <span className="font-mono text-[10px] text-brand">0{i + 1}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
