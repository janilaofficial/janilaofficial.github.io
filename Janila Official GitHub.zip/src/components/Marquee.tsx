import { Asterisk } from "lucide-react";
import { cn } from "../utils/cn";

interface MarqueeProps {
  items: string[];
  slow?: boolean;
  outline?: boolean;
  className?: string;
}

/** Infinite scrolling strip. Content is duplicated for a seamless loop. */
export default function Marquee({ items, slow, outline, className }: MarqueeProps) {
  const row = (key: string) => (
    <div key={key} className="flex shrink-0 items-center">
      {items.map((item, i) => (
        <span key={i} className="flex items-center">
          <span
            className={cn(
              "whitespace-nowrap px-6 font-display text-3xl font-extrabold tracking-tight sm:text-4xl",
              outline ? "text-stroke" : "text-paper"
            )}
          >
            {item}
          </span>
          <Asterisk className="size-6 shrink-0 text-brand" />
        </span>
      ))}
    </div>
  );

  return (
    <div
      className={cn(
        "relative flex overflow-hidden border-y border-line bg-coal py-5",
        className
      )}
    >
      <div className={cn("flex w-max", slow ? "animate-marquee-slow" : "animate-marquee")}>
        {row("a")}
        {row("b")}
      </div>
    </div>
  );
}
