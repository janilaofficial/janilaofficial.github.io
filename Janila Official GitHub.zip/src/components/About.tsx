import { BadgeCheck, Compass, Flame, Gem } from "lucide-react";
import PhotoSlot from "./PhotoSlot";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { photos, profile } from "../data/site";

const facts = [
  ["FULL NAME", `${profile.firstName} ${profile.lastName} (${profile.alias})`],
  ["ROLE", `${profile.role} — ${profile.brand}`],
  ["LOCATION", profile.location],
  ["EMAIL", profile.email],
  ["WHATSAPP", profile.whatsappDisplay],
];

const values = [
  { icon: Flame, title: "Bold Vision", text: "Thinking bigger than the market expects — and backing it with action." },
  { icon: Gem, title: "Quality First", text: "Every detail of Iconic LK is built to feel premium and earn trust." },
  { icon: Compass, title: "Own Lane", text: "Not following trends — setting a direction and staying relentless." },
];

export default function About() {
  return (
    <section id="about" className="relative mx-auto max-w-7xl px-5 py-24 sm:px-8 sm:py-32">
      <SectionHeading index="01" eyebrow="Who I Am" title="The Story" accent="So Far" />

      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        {/* photo + caption */}
        <Reveal delay={100}>
          <div className="relative">
            <PhotoSlot
              src={photos.about}
              label="ABOUT PHOTO"
              index="02"
              aspect="aspect-[16/11]"
              hint="A wide shot of you at work — edit src/data/site.ts"
            />
            <div className="mt-4 flex items-center justify-between font-mono text-[10px] tracking-[0.25em] text-muted">
              <span>FIG. 01 — THE FOUNDER</span>
              <span className="flex items-center gap-1.5 text-brand">
                <BadgeCheck className="size-3.5" /> VERIFIED HUSTLE
              </span>
            </div>
          </div>

          {/* fact sheet */}
          <dl className="mt-8 divide-y divide-line rounded-2xl border border-line bg-surface/40">
            {facts.map(([k, v]) => (
              <div key={k} className="flex flex-col gap-1 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between">
                <dt className="font-mono text-[10px] tracking-[0.25em] text-muted">{k}</dt>
                <dd className="text-sm font-medium text-paper/85">{v}</dd>
              </div>
            ))}
          </dl>
        </Reveal>

        {/* bio */}
        <div>
          <Reveal delay={200}>
            <p className="text-xl leading-relaxed text-paper/85 sm:text-2xl">
              I&apos;m <span className="text-brand">Janila</span> — an
              entrepreneur from Sri Lanka who decided that
              &ldquo;ordinary&rdquo; was never an option.
            </p>
            <p className="mt-6 leading-relaxed text-paper/60">
              What started as a single idea grew into{" "}
              <span className="font-medium text-paper/85">Iconic LK</span> — a
              brand built on obsession with quality, a sharp eye for detail,
              and the belief that world-class things can come from anywhere,
              including right here at home.
            </p>
            <p className="mt-4 leading-relaxed text-paper/60">
              This space is where I document the journey — the work, the wins,
              and everything I&apos;m building next. If you&apos;re a creator, a
              collaborator, or just curious, you&apos;re in the right place.
            </p>
          </Reveal>

          <div className="mt-10 space-y-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={250 + i * 120}>
                <div className="group flex gap-5 rounded-2xl border border-line bg-surface/40 p-6 transition-all duration-500 hover:border-brand/50 hover:bg-surface">
                  <span className="grid size-12 shrink-0 place-items-center rounded-xl border border-brand/30 bg-brand/10 text-brand transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105">
                    <v.icon className="size-5" strokeWidth={1.6} />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold">{v.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-paper/55">{v.text}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
