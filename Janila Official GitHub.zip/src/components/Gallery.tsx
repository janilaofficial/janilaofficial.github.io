import PhotoSlot from "./PhotoSlot";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { photos } from "../data/site";

const slots = [
  { label: "PORTRAIT", aspect: "aspect-[3/4]", hint: "A favourite portrait" },
  { label: "MOMENT", aspect: "aspect-[4/5]", hint: "An event or milestone" },
  { label: "WORK", aspect: "aspect-square", hint: "Behind the scenes" },
  { label: "LIFESTYLE", aspect: "aspect-[4/5]", hint: "Day in the life" },
  { label: "BRAND", aspect: "aspect-[3/4]", hint: "Iconic LK in action" },
  { label: "CANDID", aspect: "aspect-square", hint: "Anything you love" },
];

export default function Gallery() {
  return (
    <section id="gallery" className="relative mx-auto max-w-7xl px-5 py-24 sm:px-8 sm:py-32">
      <SectionHeading index="03" eyebrow="Captured" title="Frames &" accent="Moments" />

      <Reveal delay={80}>
        <p className="mb-10 max-w-md text-sm leading-relaxed text-paper/50">
          Six curated slots, ready for your favourite shots. Add image URLs in{" "}
          <span className="font-mono text-[12px] text-brand">src/data/site.ts</span>{" "}
          and each frame fills in automatically.
        </p>
      </Reveal>

      <div className="columns-2 gap-4 sm:gap-6 lg:columns-3 [&>*]:mb-4 sm:[&>*]:mb-6">
        {slots.map((s, i) => (
          <Reveal key={i} delay={i * 90} className="break-inside-avoid">
            <PhotoSlot
              src={photos.gallery[i]}
              label={s.label}
              index={String(i + 4).padStart(2, "0")}
              aspect={s.aspect}
              hint={s.hint}
            />
          </Reveal>
        ))}
      </div>
    </section>
  );
}
