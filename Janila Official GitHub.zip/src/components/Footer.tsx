import { ArrowUp } from "lucide-react";
import { links, profile } from "../data/site";
import { FacebookIcon, WhatsAppIcon } from "./icons";
import { Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative border-t border-line">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-8 px-5 py-14 sm:px-8">
        <div className="flex w-full flex-col items-center justify-between gap-8 md:flex-row">
          <a href="#home" className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-lg bg-brand font-display text-sm font-extrabold text-ink">
              JP
            </span>
            <div>
              <p className="font-display font-bold leading-none">
                {profile.firstName} <span className="text-brand">{profile.lastName}</span>
              </p>
              <p className="mt-1 font-mono text-[10px] tracking-[0.25em] text-muted">
                FOUNDER — {profile.brand.toUpperCase()}
              </p>
            </div>
          </a>

          <div className="flex items-center gap-3">
            {[
              { href: links.facebookPersonal, icon: FacebookIcon, label: "Facebook" },
              { href: links.email, icon: Mail, label: "Email" },
              { href: links.whatsapp, icon: WhatsAppIcon, label: "WhatsApp" },
            ].map((s) => (
              <a
                key={s.label}
                href={s.href}
                target={s.href.startsWith("mailto") ? undefined : "_blank"}
                rel="noreferrer"
                aria-label={s.label}
                className="grid size-11 place-items-center rounded-full border border-line text-paper/60 transition-all duration-300 hover:-translate-y-1 hover:border-brand hover:bg-brand hover:text-ink"
              >
                <s.icon className="size-4.5" strokeWidth={1.6} />
              </a>
            ))}
          </div>

          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Back to top"
            className="group grid size-11 place-items-center rounded-full border border-line text-paper/60 transition-all duration-300 hover:border-brand hover:text-brand"
          >
            <ArrowUp className="size-4.5 transition-transform duration-300 group-hover:-translate-y-0.5" />
          </button>
        </div>

        <div className="h-px w-full bg-line" />

        <p className="text-center font-mono text-[10px] leading-relaxed tracking-[0.2em] text-muted">
          © 2025 {profile.firstName.toUpperCase()} {profile.lastName.toUpperCase()} — ALL RIGHTS RESERVED
          <br />
          <span className="text-paper/40">ENGINEERED BY JANILA</span>
        </p>
      </div>
    </footer>
  );
}
