import { ArrowDown, ArrowUpRight, Asterisk, MapPin } from "lucide-react";
import PhotoSlot from "./PhotoSlot";
import { links, photos } from "../data/site";

const facts = [
  { k: "ROLE", v: "Founder & CEO" },
  { k: "BRAND", v: "Iconic LK" },
  { k: "BASE", v: "Sri Lanka" },
  { k: "STATUS", v: "Open to Connect" },
];

export default function Hero() {
  return (
    <section id="home" className="grid-lines relative overflow-hidden">
      {/* ambient glow */}
      <div className="pointer-events-none absolute -top-40 right-[-10%] h-[560px] w-[560px] rounded-full bg-brand/10 blur-[140px]" />
      <div className="pointer-events-none absolute bottom-[-20%] left-[-10%] h-[420px] w-[420px] rounded-full bg-brand/[0.06] blur-[120px]" />

      {/* giant watermark */}
      <span
        aria-hidden
        className="text-stroke-faint pointer-events-none absolute -bottom-8 left-1/2 -translate-x-1/2 select-none whitespace-nowrap font-display text-[26vw] font-extrabold leading-none tracking-tight opacity-60"
      >
        ICONIC
      </span>

      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 pb-20 pt-32 sm:px-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-center lg:gap-10 lg:pt-40">
        {/* ---- copy ---- */}
        <div>
          <div className="rise flex items-center gap-3 font-mono text-[11px] tracking-[0.3em] text-brand" style={{ "--d": "100ms" } as React.CSSProperties}>
            <span className="relative flex size-2">
              <span className="absolute inline-flex h-full w-full animate-pulse-dot rounded-full bg-brand" />
            </span>
            FOUNDER — ICONIC LK
          </div>

          <h1 className="mt-6 font-display font-extrabold leading-[0.95] tracking-tight">
            <span className="rise block text-[clamp(3.2rem,9vw,7.5rem)]" style={{ "--d": "220ms" } as React.CSSProperties}>
              JANILA
            </span>
            <span
              className="rise text-stroke block text-[clamp(2.2rem,6.4vw,5.4rem)]"
              style={{ "--d": "340ms" } as React.CSSProperties}
            >
              PRABASHWARA
            </span>
          </h1>

          <p
            className="rise mt-7 max-w-xl text-base leading-relaxed text-paper/65 sm:text-lg"
            style={{ "--d": "460ms" } as React.CSSProperties}
          >
            Entrepreneur &amp; founder of{" "}
            <span className="text-brand">Iconic LK</span> — turning bold ideas
            into a brand people remember. Building from Sri Lanka, for the
            world.
          </p>

          <div className="rise mt-9 flex flex-wrap items-center gap-4" style={{ "--d": "580ms" } as React.CSSProperties}>
            <a
              href={links.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2.5 rounded-full bg-brand px-7 py-3.5 font-mono text-xs font-medium tracking-[0.15em] text-ink transition-all duration-300 hover:bg-brand-soft hover:shadow-[0_0_40px_-8px_rgba(255,163,26,0.6)]"
            >
              START A CONVERSATION
              <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <a
              href="#about"
              className="inline-flex items-center gap-2.5 rounded-full border border-line px-7 py-3.5 font-mono text-xs tracking-[0.15em] text-paper/80 transition-all duration-300 hover:border-brand/60 hover:text-brand"
            >
              EXPLORE MY STORY
              <ArrowDown className="size-4" />
            </a>
          </div>

          <div
            className="rise mt-10 flex items-center gap-2 font-mono text-[11px] tracking-[0.2em] text-muted"
            style={{ "--d": "700ms" } as React.CSSProperties}
          >
            <MapPin className="size-3.5 text-brand" />
            BASED IN SRI LANKA — WORKING GLOBALLY
          </div>
        </div>

        {/* ---- portrait slot ---- */}
        <div className="rise relative mx-auto w-full max-w-sm lg:max-w-none" style={{ "--d": "400ms" } as React.CSSProperties}>
          {/* offset frame */}
          <div className="absolute -inset-3 -z-0 translate-x-4 translate-y-4 rounded-2xl border border-brand/25" />
          <PhotoSlot
            src={photos.portrait}
            label="PORTRAIT"
            index="01"
            aspect="aspect-[3/4]"
            hint="Add your best portrait — edit src/data/site.ts"
            className="relative rotate-2 transition-transform duration-700 hover:rotate-0"
          />

          {/* rotating badge */}
          <div className="absolute -left-8 -top-8 hidden size-28 sm:block">
            <div className="relative h-full w-full animate-spin-slow">
              <svg viewBox="0 0 100 100" className="h-full w-full">
                <defs>
                  <path id="circlePath" d="M 50,50 m -38,0 a 38,38 0 1,1 76,0 a 38,38 0 1,1 -76,0" />
                </defs>
                <text className="fill-brand font-mono text-[8.5px] tracking-[0.2em]">
                  <textPath href="#circlePath" textLength="237" lengthAdjust="spacingAndGlyphs">
                    FOUNDER · ICONIC LK · FOUNDER · ICONIC LK ·
                  </textPath>
                </text>
              </svg>
            </div>
            <Asterisk className="absolute left-1/2 top-1/2 size-6 -translate-x-1/2 -translate-y-1/2 text-brand" />
          </div>
        </div>
      </div>

      {/* ---- facts strip ---- */}
      <div className="relative border-t border-line">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-line md:grid-cols-4">
          {facts.map((f, i) => (
            <div
              key={f.k}
              className="rise px-6 py-6 sm:px-8"
              style={{ "--d": `${700 + i * 110}ms` } as React.CSSProperties}
            >
              <p className="font-mono text-[10px] tracking-[0.3em] text-brand">{f.k}</p>
              <p className="mt-2 font-display text-base font-semibold text-paper/90 sm:text-lg">{f.v}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
