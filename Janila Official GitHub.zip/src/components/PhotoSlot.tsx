import { ImagePlus } from "lucide-react";
import { cn } from "../utils/cn";

interface PhotoSlotProps {
  /** Image URL. Leave empty ("") to show the designed placeholder. */
  src?: string;
  /** Short label shown on the slot, e.g. "PORTRAIT" */
  label: string;
  /** Slot number, e.g. "01" */
  index?: string;
  /** Tailwind aspect class, e.g. "aspect-[3/4]" */
  aspect?: string;
  className?: string;
  hint?: string;
}

/**
 * A photo frame that renders a beautifully designed empty slot
 * until a real image URL is provided in src/data/site.ts.
 */
export default function PhotoSlot({
  src,
  label,
  index = "01",
  aspect = "aspect-[3/4]",
  className,
  hint = "Drop your photo here",
}: PhotoSlotProps) {
  return (
    <figure
      className={cn(
        "group relative w-full overflow-hidden rounded-2xl border",
        aspect,
        src
          ? "border-line bg-coal"
          : "border-dashed border-brand/35 bg-surface/60 hatch",
        className
      )}
    >
      {src ? (
        <img
          src={src}
          alt={label}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
        />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
          <span className="grid size-12 place-items-center rounded-full border border-brand/40 bg-brand/10 text-brand transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6">
            <ImagePlus className="size-5" strokeWidth={1.5} />
          </span>
          <div>
            <p className="font-mono text-[11px] tracking-[0.25em] text-brand">
              {label}
            </p>
            <p className="mt-1.5 text-xs text-muted">{hint}</p>
          </div>
        </div>
      )}

      {/* corner ticks */}
      <span className="absolute left-2 top-2 h-3 w-3 border-l border-t border-brand/60" />
      <span className="absolute right-2 top-2 h-3 w-3 border-r border-t border-brand/60" />
      <span className="absolute bottom-2 left-2 h-3 w-3 border-b border-l border-brand/60" />
      <span className="absolute bottom-2 right-2 h-3 w-3 border-b border-r border-brand/60" />

      {/* slot tag */}
      <figcaption className="absolute bottom-3 left-3 rounded-full border border-line bg-ink/70 px-3 py-1 font-mono text-[10px] tracking-[0.2em] text-muted backdrop-blur-sm">
        {src ? label : `SLOT ${index}`}
      </figcaption>
    </figure>
  );
}
