import { ArrowUpRight, Mail, User } from "lucide-react";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { FacebookIcon, WhatsAppIcon } from "./icons";
import { links, profile } from "../data/site";

const channels = [
  {
    icon: User,
    title: "Personal Facebook",
    handle: "Janila Dissanayake",
    sub: "@janilaofficial",
    href: links.facebookPersonal,
  },
  {
    icon: FacebookIcon,
    title: "Iconic LK — Page",
    handle: "Iconic LK",
    sub: "@iconiclk.srilanka",
    href: links.facebookBrand,
  },
  {
    icon: Mail,
    title: "Email",
    handle: "Drop me a line",
    sub: profile.email,
    href: links.email,
  },
  {
    icon: WhatsAppIcon,
    title: "WhatsApp",
    handle: profile.whatsappDisplay,
    sub: "Fastest way to reach me",
    href: links.whatsapp,
  },
];

export default function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden border-t border-line bg-coal py-24 sm:py-32">
      <div className="pointer-events-none absolute bottom-[-30%] left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-brand/[0.08] blur-[140px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading index="04" eyebrow="Get In Touch" title="Let's Build" accent="Something Iconic" />

        <Reveal>
          <p className="max-w-xl text-lg leading-relaxed text-paper/60">
            Collabs, ideas, questions or just a hello — my inbox and DMs are
            always open. Pick a channel below.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 sm:gap-5">
          {channels.map((c, i) => (
            <Reveal key={c.title} delay={i * 100}>
              <a
                href={c.href}
                target={c.href.startsWith("mailto") ? undefined : "_blank"}
                rel="noreferrer"
                className="group relative flex items-center gap-5 overflow-hidden rounded-2xl border border-line bg-surface/50 p-6 transition-all duration-500 hover:-translate-y-1 hover:border-brand/60 hover:shadow-[0_18px_50px_-20px_rgba(255,163,26,0.35)] sm:p-7"
              >
                <span className="pointer-events-none absolute -right-16 -top-16 size-40 rounded-full bg-brand/0 blur-2xl transition-all duration-700 group-hover:bg-brand/15" />

                <span className="grid size-13 shrink-0 place-items-center rounded-xl border border-brand/30 bg-brand/10 text-brand transition-all duration-500 group-hover:rotate-[-6deg] group-hover:scale-105 group-hover:bg-brand group-hover:text-ink">
                  <c.icon className="size-5.5" strokeWidth={1.6} />
                </span>

                <span className="min-w-0 flex-1">
                  <span className="block font-mono text-[10px] tracking-[0.3em] text-muted">
                    {c.title.toUpperCase()}
                  </span>
                  <span className="mt-1.5 block truncate font-display text-lg font-bold text-paper transition-colors group-hover:text-brand">
                    {c.handle}
                  </span>
                  <span className="mt-0.5 block truncate text-xs text-paper/45">{c.sub}</span>
                </span>

                <ArrowUpRight className="size-5 shrink-0 text-muted transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-brand" />
              </a>
            </Reveal>
          ))}
        </div>

        {/* big email CTA */}
        <Reveal delay={200}>
          <a
            href={links.email}
            className="group mt-14 flex flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-brand/35 bg-surface/30 px-6 py-14 text-center transition-all duration-500 hover:border-brand/70 hover:bg-surface/60"
          >
            <span className="font-mono text-[11px] tracking-[0.35em] text-brand">PREFER EMAIL?</span>
            <span className="break-all font-display text-xl font-extrabold tracking-tight text-paper transition-colors duration-300 group-hover:text-brand sm:text-3xl lg:text-4xl">
              {profile.email}
            </span>
            <span className="mt-1 inline-flex items-center gap-2 font-mono text-[10px] tracking-[0.25em] text-muted">
              CLICK TO OPEN YOUR MAIL APP
              <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </span>
          </a>
        </Reveal>
      </div>
    </section>
  );
}
