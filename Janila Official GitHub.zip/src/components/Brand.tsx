import { ArrowUpRight } from "lucide-react";
import { FacebookIcon } from "./icons";
import PhotoSlot from "./PhotoSlot";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import { links, photos } from "../data/site";

const tags = ["LIFESTYLE BRAND", "EST. SRI LANKA", "FOUNDER-LED", "QUALITY OBSESSED"];

export default function Brand() {
  return (
    <section id="brand" className="relative overflow-hidden border-t border-line bg-coal py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-brand/[0.07] blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading index="02" eyebrow="The Venture" title="Building" accent="ICONIC LK" />

        <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          {/* copy */}
          <div className="flex flex-col justify-center">
            <Reveal>
              <p className="font-mono text-[11px] tracking-[0.3em] text-brand">FOUNDER &amp; CEO</p>
              <p className="mt-5 text-lg leading-relaxed text-paper/70">
                <span className="font-display font-bold text-paper">Iconic LK</span>{" "}
                is more than a brand — it&apos;s a standard. Founded and led
                personally by me, every product, post and partnership is shaped
                to live up to one word: iconic.
              </p>
              <p className="mt-4 leading-relaxed text-paper/55">
                Follow the journey on our official page — new drops, behind the
                scenes, and the day-to-day of building something from zero.
              </p>
            </Reveal>

            <Reveal delay={120}>
              <div className="mt-7 flex flex-wrap gap-2.5">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-full border border-line bg-ink/60 px-4 py-1.5 font-mono text-[10px] tracking-[0.2em] text-paper/60 transition-colors hover:border-brand/50 hover:text-brand"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </Reveal>

            <Reveal delay={220}>
              <a
                href={links.facebookBrand}
                target="_blank"
                rel="noreferrer"
                className="group mt-9 inline-flex w-fit items-center gap-3 rounded-full border border-brand/60 px-7 py-3.5 font-mono text-xs tracking-[0.15em] text-brand transition-all duration-300 hover:bg-brand hover:text-ink hover:shadow-[0_0_44px_-10px_rgba(255,163,26,0.7)]"
              >
                <FacebookIcon className="size-4" />
                FOLLOW ICONIC LK
                <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </Reveal>
          </div>

          {/* brand cover slot */}
          <Reveal delay={150}>
            <div className="relative">
              <div className="absolute -inset-px rounded-2xl bg-gradient-to-br from-brand/40 via-transparent to-brand/20 blur-[2px]" />
              <PhotoSlot
                src={photos.brand}
                label="BRAND COVER"
                index="03"
                aspect="aspect-[16/10]"
                hint="Iconic LK cover or product shot — edit src/data/site.ts"
                className="relative"
              />
              <div className="mt-4 flex items-center justify-between font-mono text-[10px] tracking-[0.25em] text-muted">
                <span>FIG. 02 — THE BRAND</span>
                <span className="text-brand">@ICONICLK.SRILANKA</span>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
