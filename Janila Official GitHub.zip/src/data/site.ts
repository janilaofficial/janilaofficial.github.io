/* ------------------------------------------------------------------
   CENTRAL CONFIG — edit this file to update the whole site.
   ------------------------------------------------------------------
   PHOTOS / ඡායාරූප:
   Paste your image URLs into the empty quotes below, e.g.
   portrait: "https://your-image-link.jpg"
   ...හෝ image එක project එකේ  public/photos/ folder එකට දාලා
   මෙහෙම ලියන්න:  portrait: "/photos/me.jpg"
   Empty ("") = a beautiful placeholder slot is shown automatically.
------------------------------------------------------------------- */

export const photos = {
  /** Hero section — vertical portrait (3:4 works best) */
  portrait: "",
  /** About section — wide shot (16:10 works best) */
  about: "",
  /** Brand section — Iconic LK cover / product shot (16:9) */
  brand: "",
  /** Gallery — 6 favourite shots, any orientation */
  gallery: ["", "", "", "", "", ""] as string[],
};

export const profile = {
  firstName: "Janila",
  lastName: "Prabashwara",
  alias: "Janila Dissanayake",
  role: "Founder & CEO",
  brand: "Iconic LK",
  location: "Sri Lanka",
  email: "janilaprabashwaraofficial@gmail.com",
  whatsappDisplay: "+94 71 889 2936",
};

export const links = {
  facebookPersonal: "https://www.facebook.com/janilaofficial",
  facebookBrand: "https://www.facebook.com/iconiclk.srilanka",
  email: `mailto:${profile.email}`,
  whatsapp: "https://wa.me/94718892936",
};

export const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "The Brand", href: "#brand" },
  { label: "Gallery", href: "#gallery" },
  { label: "Contact", href: "#contact" },
];
