import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import About from "./components/About";
import Brand from "./components/Brand";
import Gallery from "./components/Gallery";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="grain min-h-screen bg-ink text-paper antialiased">
      <Nav />
      <main>
        <Hero />
        <Marquee
          items={["JANILA PRABASHWARA", "FOUNDER", "ICONIC LK", "ENTREPRENEUR", "SRI LANKA"]}
        />
        <About />
        <Marquee
          slow
          outline
          items={["BUILD DIFFERENT", "STAY ICONIC", "NO SHORTCUTS", "QUALITY FIRST"]}
        />
        <Brand />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
